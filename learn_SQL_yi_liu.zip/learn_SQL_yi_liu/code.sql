/*Q1: what columns does the table have?*/
 SELECT *
 FROM survey
 LIMIT 10;
 
 /*Q2: what is the number of responses for each question?*/
 SELECT question, COUNT(DISTINCT (user_id)) AS 'user_number'
 FROM survey
 GROUP BY question;
 
/*Q4: What are the column names?*/     
SELECT *
FROM quiz
LIMIT 5;
SELECT *
FROM home_try_on
LIMIT 5;
SELECT *
FROM purchase
LIMIT 5;      

/*Q5: combine the three tables*/   
SELECT q.user_id,
h.user_id IS NOT NULL AS 'is_home_try_on', h.number_of_pairs, p.user_id IS NOT NULL AS 'is_purchase'
FROM quiz AS 'q'
LEFT JOIN home_try_on AS 'h'           
ON q.user_id=h.user_id
LEFT JOIN purchase AS 'p'
ON h.user_id=p.user_id
LIMIT 10;
                                  
/*Q6*/                                 
WITH funnel AS 
(SELECT q.user_id,
h.user_id IS NOT NULL AS 'is_home_try_on', h.number_of_pairs, p.user_id IS NOT NULL AS 'is_purchase'
FROM quiz AS 'q'
LEFT JOIN home_try_on AS 'h'           
ON q.user_id=h.user_id
LEFT JOIN purchase AS 'p'
ON h.user_id=p.user_id
LIMIT 10)
SELECT COUNT(user_id) AS 'participants_number', SUM(is_home_try_on) AS 'tryon_number', SUM(is_purchase) AS 'purchase_number',
/*calculate the conversion from quiz to home_try_on*/                       
1.0 * SUM(is_home_try_on) /COUNT(user_id) AS '%q2h',
/*calculate the conversion from home_try_on to purchase*/
1.0 * SUM(is_purchase)/SUM(is_home_try_on) AS '%p2t'                            
FROM funnel;

                    

/*Q6: what is the most three popular color*/
SELECT COUNT(user_id), color
FROM quiz
GROUP BY 2
ORDER BY 1 DESC
LIMIT 3;                                


